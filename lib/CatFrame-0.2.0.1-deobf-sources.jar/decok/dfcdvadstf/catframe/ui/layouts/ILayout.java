package decok.dfcdvadstf.catframe.ui.layouts;

public interface ILayout {
    void setX(int x);
    void setY(int y);

    int getX();
    int getY();

    int getWidth();
    int getHeight();

    default void setPosition(final int x, final int y){
        this.setX(x);
        this.setY(y);
    }
}
