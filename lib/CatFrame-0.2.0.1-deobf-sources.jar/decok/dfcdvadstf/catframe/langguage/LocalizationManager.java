package decok.dfcdvadstf.catframe.langguage;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import decok.dfcdvadstf.catframe.CatFrame;
import net.minecraft.client.Minecraft;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * JSON-based localization manager with namespace support, similar to higher
 * Minecraft versions.
 * <p>
 * 基于 JSON 的命名空间本地化管理器，类似高版本 Minecraft。
 * <p>
 * Keys are stored internally as {@code domain:key}. You can pass them in two
 * forms:
 * <pre>{@code
 *   LocalizationManager.translate("catframe:menu.paused");
 *   LocalizationManager.translate("catframe", "menu.paused", args...);
 * }</pre>
 * <p>
 * Must call {@link LanguageRegister#domain(String, String)} for each mod
 * domain BEFORE calling {@link #load()}.
 */
public final class LocalizationManager {

    /** Separator between domain and key */
    public static final char DOMAIN_SEPARATOR = ':';

    private static final Gson GSON = new Gson();
    private static final Type MAP_TYPE = new TypeToken<Map<String, String>>() {}.getType();

    /** Current-language translations: "domain:key" → text */
    private static final Map<String, String> translations = new HashMap<>();

    /** Fallback (en_US) translations: "domain:key" → text */
    private static final Map<String, String> fallback = new HashMap<>();

    /** Keys that have been marked as enabled/translatable: "domain:key" */
    private static final Set<String> enabledKeys = new HashSet<>();

    private static boolean loaded = false;

    private LocalizationManager() {}

    // ──── Load / Reload ────

    /**
     * Loads translations from all registered domains. Must be called AFTER all
     * {@link LanguageRegister#domain} calls, on the client side.
     * <p>
     * 从所有已注册域加载翻译。必须在所有 {@link LanguageRegister#domain} 调用之后、
     * 在客户端侧调用。
     */
    @SideOnly(Side.CLIENT)
    public static void load() {
        if (loaded) return;

        String currentLang = getCurrentLanguage();

        for (Map.Entry<String, String> entry : LanguageRegister.domains.entrySet()) {
            String domain = entry.getKey();
            String basePath = entry.getValue();

            // Always load en_US as fallback
            loadDomainFile(domain, basePath, "en_US", fallback);

            // Load current language (skip if already en_US)
            if (!"en_US".equals(currentLang)) {
                loadDomainFile(domain, basePath, currentLang, translations);
            }
        }

        // Fill missing entries from fallback
        for (Map.Entry<String, String> entry : fallback.entrySet()) {
            if (!translations.containsKey(entry.getKey())) {
                translations.put(entry.getKey(), entry.getValue());
            }
        }

        loaded = true;
        CatFrame.logger.info("LocalizationManager loaded: lang={}, domains={}, keys={}",
                currentLang, LanguageRegister.domains.size(), translations.size());
    }

    /**
     * Reloads all translations (useful for language switching at runtime).
     * <p>
     * 重新加载所有翻译（用于运行时切换语言）。
     */
    @SideOnly(Side.CLIENT)
    public static void reload() {
        translations.clear();
        loaded = false;
        load();
    }

    // ──── Translate ────

    /**
     * Translates using a {@code domain:key} string.
     * <p>
     * 使用 {@code domain:key} 格式的字符串进行翻译。
     * <pre>{@code
     *   LocalizationManager.translate("catframe:menu.paused");
     *   LocalizationManager.translate("catframe:item.count", 5);
     * }</pre>
     */
    public static String translate(String resourceKey, Object... args) {
        int sep = resourceKey.indexOf(DOMAIN_SEPARATOR);
        if (sep <= 0) {
            CatFrame.logger.warn("Translation key missing domain separator ':': {}", resourceKey);
            return resourceKey;
        }
        String domain = resourceKey.substring(0, sep);
        String key = resourceKey.substring(sep + 1);
        return translate(domain, key, args);
    }

    /**
     * Translates with explicit domain and key, similar to
     * {@code new ResourceLocation(domain, path)}.
     * <p>
     * 使用独立的域和键进行翻译，类似 {@code new ResourceLocation(domain, path)}。
     * <pre>{@code
     *   LocalizationManager.translate("catframe", "menu.paused");
     *   LocalizationManager.translate("catframe", "item.count", 5);
     * }</pre>
     */
    public static String translate(String domain, String key, Object... args) {
        String fullKey = domain + DOMAIN_SEPARATOR + key;
        String text = translations.get(fullKey);
        if (text == null) {
            text = fallback.get(fullKey);
        }
        if (text == null) {
            CatFrame.logger.warn("Missing translation for: {}", fullKey);
            return args.length > 0 ? fullKey + " " + Arrays.toString(args) : fullKey;
        }
        if (args.length > 0) {
            try {
                return String.format(text, args);
            } catch (Exception e) {
                CatFrame.logger.warn("Format error for '{}': {}", fullKey, e.getMessage());
            }
        }
        return text;
    }

    // ──── Key lookup ────

    /**
     * Checks whether a {@code domain:key} exists.
     * <p>
     * 检查 {@code domain:key} 是否存在。
     */
    public static boolean hasKey(String resourceKey) {
        return translations.containsKey(resourceKey) || fallback.containsKey(resourceKey);
    }

    /**
     * Checks whether a domain+key pair exists.
     * <p>
     * 检查 domain+key 对是否存在。
     */
    public static boolean hasKey(String domain, String key) {
        String fullKey = domain + DOMAIN_SEPARATOR + key;
        return hasKey(fullKey);
    }

    // ──── Enabled / translatable key tracking ────

    /**
     * Marks a key as "enabled" — called by {@link decok.dfcdvadstf.catframe.ui.Text#setTranslatable}.
     * <p>
     * 将一个键标记为"启用" —— 由 {@link decok.dfcdvadstf.catframe.ui.Text#setTranslatable} 调用。
     */
    public static void markEnabled(String domain, String key) {
        enabledKeys.add(domain + DOMAIN_SEPARATOR + key);
    }

    /**
     * Returns whether the given domain+key has been marked as enabled.
     * <p>
     * 返回给定的 domain+key 是否已被标记为启用。
     */
    public static boolean isEnabled(String domain, String key) {
        return enabledKeys.contains(domain + DOMAIN_SEPARATOR + key);
    }

    /**
     * Returns an unmodifiable view of all enabled resource keys.
     * <p>
     * 返回所有已启用资源键的不可修改视图。
     */
    public static Set<String> getEnabledKeys() {
        return Collections.unmodifiableSet(enabledKeys);
    }

    // ──── Internal ────

    @SideOnly(Side.CLIENT)
    private static String getCurrentLanguage() {
        try {
            return Minecraft.getMinecraft().getLanguageManager()
                    .getCurrentLanguage().getLanguageCode();
        } catch (Exception e) {
            CatFrame.logger.warn("Failed to detect language, falling back to en_US", e);
            return "en_US";
        }
    }

    @SideOnly(Side.CLIENT)
    private static void loadDomainFile(String domain, String basePath,
                                        String langCode, Map<String, String> target) {
        String path = "/" + basePath + "/" + langCode + ".json";
        try (InputStream in = LocalizationManager.class.getResourceAsStream(path)) {
            if (in == null) {
                CatFrame.logger.warn("Language file not found: {}", path);
                return;
            }
            Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8);
            Map<String, String> data = GSON.fromJson(reader, MAP_TYPE);
            if (data != null) {
                for (Map.Entry<String, String> entry : data.entrySet()) {
                    target.put(domain + DOMAIN_SEPARATOR + entry.getKey(), entry.getValue());
                }
                CatFrame.logger.info("Loaded {} keys from {}:{} ({})",
                        data.size(), domain, langCode, path);
            }
        } catch (Exception e) {
            CatFrame.logger.error("Failed to load language file: {}", path, e);
        }
    }
}
